// member.model.js
const mongoose = require("mongoose");

const memberSchema = new mongoose.Schema(
  {
    BranchMember: { type: String, required: true },
    CenterIDMember: { type: String, required: true },
    CenterNameMember: { type: String, required: true },
    memberID: { type: String, unique: true, required: true },
    AdmissionDate: { type: String, default: null },
    memberName: { type: String, required: true },
    MfhName: { type: String, required: true },
    memberJob: { type: String, required: true },
    memberVillage: { type: String, required: true },
    memberUnion: { type: String, required: true },
    memberPost: { type: String, required: true },
    memberSubDic: { type: String, required: true },
    MdateOfBirth: { type: String, default: null },
    memberDic: { type: String, required: true },
    memberMarital: { type: String, required: true },
    memberStudy: { type: String, required: true },
    memberFhead: { type: String, required: true },
    memberfMM: { type: String, required: true },
    memberfMF: { type: String, required: true },
    memberfMTotal: { type: String, required: true },
    EarningMember: { type: String, required: true },
    FamilyMemberENO: { type: String },
    loanamount: { type: String },
    nonorganizaiotnloan: { type: String },
    YearlyIncome: { type: String, required: true },
    LandProperty: { type: String, required: true },
    TotalMoney: { type: String, required: true },
    MemberNIDnumber: { type: String, required: true },
    MemberMobile: { type: String, required: true },
    NominiName: { type: String, required: true },
    NominiFather: { type: String, required: true },
    MemberNominiRelation: { type: String, required: true },
    AdmissionFee: { type: Number, required: true },
    FormFee: { type: Number, required: true },
    agreementChecked: { type: Boolean, required: true },
    approvalStatus: {
      type: String,
      enum: ["Pending", "Approved", "Granted", "Needs Correction"],
      default: "Pending",
    },
    ActiveStatus: {
      type: String,
      enum: ["True", "False"],
      default: "True",
    },
    submittedBy: { type: String, required: true },
    ApprovedBy: { type: String, default: "Null", required: true },
    GrantedBy: { type: String, default: "Null", required: true },
    DeletedBy: { type: String, default: "Null", required: true },
    DeleteDate: { type: Date, default: null },
  },
  { timestamps: true }
);

const Member = mongoose.model("Member", memberSchema);

module.exports = Member;
