// member.model.js
const mongoose = require("mongoose");

const memberSchema = new mongoose.Schema(
  {
    BranchMember: { type: String },
    CenterMember: { type: String },
    memberID: { type: String, unique: true, required: true },
    memberName: { type: String, required: true },
    MfhName: { type: String, required: true },
    memberJob: { type: String, required: true },
    memberVillage: { type: String, required: true },
    memberUnion: { type: String, required: true },
    memberPost: { type: String, required: true },
    memberSubDic: { type: String, required: true },
    MdateOfBirth: { type: String, default: null },
    memberDic: { type: String, required: true },
    memberMarital: { type: String, required: true },
    memberStudy: { type: String, required: true },
    memberFhead: { type: String, required: true },
    memberfMM: { type: Number, required: true },
    memberfMF: { type: Number, required: true },
    memberfMTotal: { type: Number, required: true },
    EarningMember: { type: Number, required: true },
    FamilyMemberENO: { type: String, required: true },
    loanamount: { type: Number },
    nonorganizaiotnloan: { type: Number },
    YearlyIncome: { type: Number, required: true },
    LandProperty: { type: String, required: true },
    TotalMoney: { type: String, required: true },
    MemberNIDnumber: { type: Number, required: true },
    MemberMobile: { type: Number, required: true },
    NominiName: { type: String, required: true },
    NominiFather: { type: String, required: true },
    MemberNominiRelation: { type: String, required: true },
    agreementChecked: { type: Boolean, required: true },
  },
  { timestamps: true }
);

const Member = mongoose.model("Member", memberSchema);

module.exports = Member;
